/**
 * The Addition class provides methods to perform addition of integers.
 *  @author Mohammad Rokibul Hassan Shanto,<br>Roll: 400<br>
 */
public class Addition {

    /**
     * Adds two integers together.

     * @param firstNum the first integer
     * @param secondNum the second integer
     * @return the sum of firstNum and secondNum
     */
    public int doAddition1(int firstNum, int secondNum) {
        return firstNum + secondNum;
    }

    /**
     * Adds three integers together.
     *
     * @param firstNum the first integer
     * @param secondNum the second integer
     * @param thirdNum the third integer
     * @return the sum of firstNum, secondNum, and thirdNum
     */

    public int doAddition2(int firstNum, int secondNum, int thirdNum) {
        return firstNum + secondNum + thirdNum;
    }

}

