/**
 * @author Ali Jakey Shariar,<br>Roll: 397<br>
 * The Subtraction class provides methods to perform subtraction operations.
 */
public class Subtraction {

    /**
     * Constructor for the Subtraction class.
     * This constructor initializes a Subtraction object.
     */
    public Subtraction() {
        System.out.println("Subtraction object created!");
    }

    /**
     * Subtracts two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the result of subtracting b from a
     */
    public int subtract(int a, int b) {
        return a - b;
    }

    /**
     * Subtracts two doubles.
     *
     * @param a the first double
     * @param b the second double
     * @return the result of subtracting b from a
     */
    public double subtract(double a, double b) {
        return a - b;
    }
}
