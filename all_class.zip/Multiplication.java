/**
 * @author Md. Mahfuzur Rahman ,<br>Roll: 404<br>
 * This class provides methods to perform multiplication operations
 * with various input types (double, int, and String).
 */
public class Multiplication {

    /**
     * Multiplies two double numbers.
     * @param multiplicand the number to be multiplied
     * @param multiplier the number to multiply by
     * @return the result of the multiplication
     */
    public static double multiply(double multiplicand, double multiplier) {
        return multiplicand * multiplier;
    }

    /**
     * Multiplies two integer numbers.s
     * @param multiplicand the number to be multiplied
     * @param multiplier the number to multiply by
     * @return the result of the multiplication
     */
    public static int multiply(int multiplicand, int multiplier) {
        return multiplicand * multiplier;
    }

    /**
     * Multiplies two numbers represented as strings.
     *
     * @param multiplicand the number to be multiplied as a String
     * @param multiplier the number to multiply by as a String
     * @return the result of the multiplication
     * @throws IllegalArgumentException if input is invalid
     */
    public static double multiply(String multiplicand, String multiplier) {
        try {
            double num1 = Double.parseDouble(multiplicand);
            double num2 = Double.parseDouble(multiplier);
            return multiply(num1, num2);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid input: " + e.getMessage());
        }
    }
}
