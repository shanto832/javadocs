/**
 * @author Md. Mahfuz Molla,<br>Roll: 395<br>
 * The Division class provides methods to perform division
 * operations on different numeric types, demonstrating method overloading.
 * 
 *
 */
public class Division {
    /**
     * This is a default constructor
     */
    public Division(){

    }

    /**
     * Divides two integers.
     *
     * @param firstNumber the dividend
     * @param secondNumber the divisor
     * @return the result of the division
     * @throws IllegalArgumentException if the divisor is zero
     */
    public int divide(int firstNumber, int secondNumber) {
        if (secondNumber == 0) {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
        return firstNumber / secondNumber;
    }

    /**
     * Divides two double values.
     *
     * @param firstNumber the dividend
     * @param secondNumber the divisor
     * @return the result of the division
     * @throws IllegalArgumentException if the divisor is zero
     */
    public double divide(double firstNumber, double secondNumber) {
        if (secondNumber == 0.0) {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
        return firstNumber / secondNumber;
    }

    /**
     * Divides two float values.
     *
     * @param firstNumber the dividend
     * @param secondNumber the divisor
     * @return the result of the division
     * @throws IllegalArgumentException if the divisor is zero
     */
    public float divide(float firstNumber, float secondNumber) {
        if (secondNumber == 0.0f) {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
        return firstNumber / secondNumber;
    }

}
