/**
 * @author Mamunur Roshid,<br>Roll: 371<br>
 * PrimeChecker class provides a method to check if a number is prime.
 * 
 * <p>This class includes a constructor and a method to determine if a given number is prime.</p>
 */
public class PrimeChecker {
    /**
     * Constructor for PrimeChecker.
     */
    public PrimeChecker() {

    }

    /**
     * Checks if a number is prime.
     * 
     * @param number the number to check
     * @return true if the number is prime, false otherwise
     */
    public boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

}
