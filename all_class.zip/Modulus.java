/**
 * @author Md. Shakhawat Hosen,<br>Roll: 376<br>
 * This class provides methods to perform modulus operations
 * with various input types (double, int, and String).
 */
public class Modulus {

    /**
     * Calculates the modulus of two double numbers.
     *
     * @param dividend the number to be divided
     * @param divisor  the number to divide by
     * @return the result of the modulus operation
     * @throws IllegalArgumentException if the divisor is zero
     */
    public static double mod(double dividend, double divisor) {
        if (divisor == 0) {
            throw new IllegalArgumentException("Divisor cannot be zero.");
        }
        return dividend % divisor;
    }

    /**
     * Calculates the modulus of two integer numbers.
     *
     * @param dividend the number to be divided
     * @param divisor  the number to divide by
     * @return the result of the modulus operation
     * @throws IllegalArgumentException if the divisor is zero
     */
    public static int mod(int dividend, int divisor) {
        if (divisor == 0) {
            throw new IllegalArgumentException("Divisor cannot be zero.");
        }
        return dividend % divisor;
    }

    /**
     * Calculates the modulus of two numbers represented as strings.
     *
     * @param dividend the number to be divided as a String
     * @param divisor  the number to divide by as a String
     * @return the result of the modulus operation
     * @throws IllegalArgumentException if the divisor is zero or input is invalid
     */
    public static double mod(String dividend, String divisor) {
        try {
            double num1 = Double.parseDouble(dividend);
            double num2 = Double.parseDouble(divisor);
            return mod(num1, num2);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid input: " + e.getMessage());
        }
    }
}

